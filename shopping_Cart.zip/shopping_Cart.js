// Smart Shopping Cart Optimizer (Console Based)
// Full Project Code
// Includes:
// User Input
// Greedy Algorithm
// Dynamic Programming
// Priority Mode
// Add / Remove Products
// Save Bill to Text File

const readline = require("readline");
const fs = require("fs");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Input Function
function ask(question) {
  return new Promise(resolve => rl.question(question, ans => resolve(ans)));
}

// ----------------------------
// Priority Sorting
// ----------------------------
function sortByPriority(items, mode) {
  if (mode === "1") {
    return [...items].sort((a, b) => a.price - b.price); // Lowest Cost
  } else if (mode === "2") {
    return [...items].sort((a, b) => b.satisfaction - a.satisfaction); // Highest Satisfaction
  } else {
    return [...items].sort(
      (a, b) =>
        (b.satisfaction / b.price) - (a.satisfaction / a.price)
    ); // Balanced Choice
  }
}

// ----------------------------
// Greedy Algorithm
// ----------------------------
function greedyKnapsack(items, budget, mode) {
  const sorted = sortByPriority(items, mode);

  let chosen = [];
  let totalCost = 0;
  let totalSatisfaction = 0;

  for (let item of sorted) {
    if (totalCost + item.price <= budget) {
      chosen.push(item);
      totalCost += item.price;
      totalSatisfaction += item.satisfaction;
    }
  }

  return { chosen, totalCost, totalSatisfaction };
}

// ----------------------------
// Dynamic Programming
// ----------------------------
function dpKnapsack(items, budget) {
  const n = items.length;

  const dp = Array.from({ length: n + 1 }, () =>
    Array(budget + 1).fill(0)
  );

  for (let i = 1; i <= n; i++) {
    for (let w = 0; w <= budget; w++) {
      if (items[i - 1].price <= w) {
        dp[i][w] = Math.max(
          items[i - 1].satisfaction + dp[i - 1][w - items[i - 1].price],
          dp[i - 1][w]
        );
      } else {
        dp[i][w] = dp[i - 1][w];
      }
    }
  }

  let chosen = [];
  let w = budget;

  for (let i = n; i > 0; i--) {
    if (dp[i][w] !== dp[i - 1][w]) {
      chosen.push(items[i - 1]);
      w -= items[i - 1].price;
    }
  }

  chosen.reverse();

  return {
    chosen,
    totalCost: budget - w,
    totalSatisfaction: dp[n][budget]
  };
}

// ----------------------------
// Save Bill
// ----------------------------
function saveBill(greedyResult, dpResult, budget) {
  let content = "===== SMART SHOPPING BILL =====\n\n";

  content += "---- Greedy Result ----\n";
  greedyResult.chosen.forEach(item => {
    content += `${item.name} - ₹${item.price}\n`;
  });
  content += `Total Cost: ₹${greedyResult.totalCost}\n`;
  content += `Total Satisfaction: ${greedyResult.totalSatisfaction}\n\n`;

  content += "---- DP Result ----\n";
  dpResult.chosen.forEach(item => {
    content += `${item.name} - ₹${item.price}\n`;
  });
  content += `Total Cost: ₹${dpResult.totalCost}\n`;
  content += `Total Satisfaction: ${dpResult.totalSatisfaction}\n\n`;

  content += `Budget: ₹${budget}\n`;

  fs.writeFileSync("bill.txt", content);
}

// ----------------------------
// Main Program
// ----------------------------
async function main() {
  console.log("===== SMART SHOPPING CART OPTIMIZER =====");

  let items = [];

  let count = parseInt(await ask("Enter number of products: "));

  for (let i = 0; i < count; i++) {
    console.log(`\nProduct ${i + 1}`);

    const name = await ask("Enter product name: ");
    const price = parseInt(await ask("Enter price: "));
    const satisfaction = parseInt(await ask("Enter satisfaction score (1-100): "));

    items.push({ name, price, satisfaction });
  }

  // Remove Product
  let removeChoice = await ask("\nDo you want to remove any product? (yes/no): ");

  if (removeChoice.toLowerCase() === "yes") {
    let removeName = await ask("Enter product name to remove: ");

    items = items.filter(
      item => item.name.toLowerCase() !== removeName.toLowerCase()
    );

    console.log("Product removed successfully.");
  }

  // Add Product
  let addChoice = await ask("Do you want to add new product? (yes/no): ");

  if (addChoice.toLowerCase() === "yes") {
    const name = await ask("Enter product name: ");
    const price = parseInt(await ask("Enter price: "));
    const satisfaction = parseInt(await ask("Enter satisfaction score: "));

    items.push({ name, price, satisfaction });

    console.log("Product added successfully.");
  }

  const budget = parseInt(await ask("\nEnter your budget: "));

  // Priority Mode
  console.log("\nChoose Priority Mode:");
  console.log("1. Lowest Cost");
  console.log("2. Highest Satisfaction");
  console.log("3. Balanced Choice");

  const mode = await ask("Enter option (1/2/3): ");

  // Run Algorithms
  const greedyResult = greedyKnapsack(items, budget, mode);
  const dpResult = dpKnapsack(items, budget);

  // Output
  console.log("\n===== GREEDY RESULT =====");
  console.log("Items:", greedyResult.chosen.map(i => i.name).join(", "));
  console.log("Total Cost: ₹" + greedyResult.totalCost);
  console.log("Total Satisfaction:", greedyResult.totalSatisfaction);

  console.log("\n===== DP RESULT =====");
  console.log("Items:", dpResult.chosen.map(i => i.name).join(", "));
  console.log("Total Cost: ₹" + dpResult.totalCost);
  console.log("Total Satisfaction:", dpResult.totalSatisfaction);

  // Winner
  if (dpResult.totalSatisfaction > greedyResult.totalSatisfaction) {
    console.log("\nDP gives better result.");
  } else if (dpResult.totalSatisfaction < greedyResult.totalSatisfaction) {
    console.log("\nGreedy gives better result.");
  } else {
    console.log("\nBoth give same result.");
  }

  // Save Bill
  saveBill(greedyResult, dpResult, budget);

  console.log("\nBill saved as bill.txt");

  rl.close();
}

main();